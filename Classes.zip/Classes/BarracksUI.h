// BarracksUI.h
#ifndef __BARRACKS_UI_H__
#define __BARRACKS_UI_H__
#include "cocos2d.h"
#include "ui/CocosGUI.h"

class RecruitUI;
class BarracksUI : public cocos2d::Layer
{
private:
    void initButtons();               // ��ʼ����ť
    cocos2d::ui::Layout* m_mainPanel; // �����
public:
    virtual bool init() override;
    CREATE_FUNC(BarracksUI);

    void show(); // ��ʾ��ӪUI
    void hide(); // ���ؾ�ӪUI
};

#endif
// BarracksUI.h