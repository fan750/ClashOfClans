//GameEntity.cpp
#include "GameEntity.h"
USING_NS_CC;

GameEntity::GameEntity() : m_maxHp(100), m_currentHp(100), m_camp(CampType::NEUTRAL) {}
GameEntity::~GameEntity() {}

bool GameEntity::init()
{
    if (!Sprite::init()) { return false; } // �ȵ��ø��� Sprite �� init
    return true;                           // ��ʼ���ɹ�
}

void GameEntity::setProperties(int maxHp, CampType camp) // ����Ѫ������Ӫ
{
    this->m_maxHp = maxHp;
    this->m_currentHp = maxHp;
    this->m_camp = camp;
}

void GameEntity::takeDamage(int damage) // ����
{
    if (isDead()) return;
    m_currentHp -= damage;
    CCLOG("Entity Took Damage. Remaining: %d", m_currentHp);

    if (m_currentHp <= 0) 
    {
        m_currentHp = 0;
        onDeath();
    }
}

void GameEntity::onDeath() { this->removeFromParent(); } // ����ɾ��

void GameEntity::updateLogic(float dt) // ��ʱ����
{ 

}

void GameEntity::update(float dt)
{
    this->updateLogic(dt);
}
//GameEntity.cpp