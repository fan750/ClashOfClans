//GameUI.cpp
#include "GameUI.h"
#include "GameManager.h" // ��Ҫ��ȡ����
USING_NS_CC;

bool GameUI::init() 
{
    if (!Layer::init()) 
    {
        return false;
    }

    Size visibleSize = Director::getInstance()->getVisibleSize();

    // ��ʼ����Դ��ǩ
    initResourceLabels();
    // ��ʼ�������ֱ�ǩ
    initTroopLabels();

    // ������Ҹ����¼�
    auto goldListener = EventListenerCustom::create
    ("EVENT_UPDATE_GOLD", [this](EventCustom* event)
        {
            this->updateLabels();
        }
    );
    _eventDispatcher->addEventListenerWithSceneGraphPriority(goldListener, this);

    // ����ʥˮ�����¼�
    auto elixirListener = EventListenerCustom::create("EVENT_UPDATE_ELIXIR", [this](EventCustom* event)
        {
            this->updateLabels();
        });
    _eventDispatcher->addEventListenerWithSceneGraphPriority(elixirListener, this);

    // �����������������¼�
    auto troopListener = EventListenerCustom::create
    ("EVENT_UPDATE_TROOPS", [this](EventCustom* event)
        {
        this->updateLabels();
        }
    );
    _eventDispatcher->addEventListenerWithSceneGraphPriority(troopListener, this);
    // ��ʼ����ʾһ��
    updateLabels();

    return true;
}

void GameUI::initResourceLabels()
{
    Size visibleSize = Director::getInstance()->getVisibleSize();

    // ������ұ�ǩ
    m_goldLabel = Label::createWithSystemFont("Gold: 0", "Arial", 24);
    m_goldLabel->setColor(Color3B::YELLOW);
    m_goldLabel->setPosition(Vec2(visibleSize.width - 100, visibleSize.height - 30));
    m_goldLabel->setAnchorPoint(Vec2(1, 0.5));
    this->addChild(m_goldLabel);

    // ����ʥˮ��ǩ
    m_elixirLabel = Label::createWithSystemFont("Elixir: 0", "Arial", 24);
    m_elixirLabel->setColor(Color3B::MAGENTA);
    m_elixirLabel->setPosition(Vec2(visibleSize.width - 100, visibleSize.height - 60));
    m_elixirLabel->setAnchorPoint(Vec2(1, 0.5));
    this->addChild(m_elixirLabel);
}

void GameUI::initTroopLabels() // ��ʼ�������ֱ�ǩ
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float startY = visibleSize.height - 90; // ��ʼY����
    float lineHeight = 25; // �и�

    // ������Ϣ����
    struct TroopInfo
    {
        TroopType type;
        std::string name;
        Color3B color;
    };

    std::vector<TroopInfo> troopTypes = 
    {
        {TroopType::BARBARIAN, "Barbarian:", Color3B::GREEN},
        {TroopType::ARCHER, "Archer:", Color3B::MAGENTA},
        {TroopType::GIANT, "Giant:", Color3B::ORANGE},
        {TroopType::BOMBERMAN, "Bomberman:", Color3B::GRAY}
    };

    // Ϊÿ�ֱ��ִ�����ǩ
    for (size_t i = 0; i < troopTypes.size(); ++i) 
    {
        const TroopInfo& info = troopTypes[i];

        // ������ǩ����ʼ��ʾ"����: 0"
        auto label = Label::createWithSystemFont(info.name + " 0", "Arial", 20);
        label->setColor(info.color);
        label->setPosition(Vec2(visibleSize.width - 100, startY - i * lineHeight));
        label->setAnchorPoint(Vec2(1, 0.5));
        this->addChild(label);

        // ���浽map��
        m_troopLabels[info.type] = label;
    }
}

void GameUI::updateLabels() 
{
    // �� GameManager ȡ����ҡ�ʥˮ����������
    int gold = GameManager::getInstance()->getGold();
    int elixir = GameManager::getInstance()->getElixir();
    m_goldLabel->setString("Gold: " + std::to_string(gold));
    m_elixirLabel->setString("Elixir: " + std::to_string(elixir));
    // ���¸���������
    auto gm = GameManager::getInstance();
    for (const auto& pair : m_troopLabels)
    {
        TroopType type = pair.first;
        Label* label = pair.second;
        int count = gm->getTroopCount(type);

        // ��ȡ��������
        std::string troopName;
        Color3B troopColor;
        switch (type)
        {
        case TroopType::BARBARIAN:troopName = "Barbarian:";troopColor = Color3B::GREEN;  break;
        case TroopType::ARCHER:   troopName = "Archer:";   troopColor = Color3B::MAGENTA;break;
        case TroopType::GIANT:    troopName = "Giant:";    troopColor = Color3B::ORANGE; break;
        case TroopType::BOMBERMAN:troopName = "Bomberman:";troopColor = Color3B::GRAY;   break;
        }

        // ���±�ǩ�ı�����ɫ
        label->setString(troopName + " " + std::to_string(count));
        label->setColor(troopColor);
    }
}
//GameUI.cpp