//BattleManager.cpp
#include "BattleManager.h"
#include "Troop.h"
#include "GameManager.h"
USING_NS_CC;

BattleManager* BattleManager::s_instance = nullptr;

BattleManager::BattleManager() {}

BattleManager* BattleManager::getInstance() // ����ս��������ʵ��
{
    if (!s_instance) 
    {
        s_instance = new BattleManager();
    }
    return s_instance;
}

void BattleManager::addBuilding(Building* building)
{
    if (!m_buildings.contains(building)) 
    {
        m_buildings.pushBack(building);
    }
}

void BattleManager::removeBuilding(Building* building) 
{
    if (m_buildings.contains(building)) 
    {
        m_buildings.eraseObject(building);
    }
}

Building* BattleManager::findClosestBuilding(Vec2 position)
{
    Building* closestNode = nullptr;
    float minDistance = 999999.0f;

    for (auto building : m_buildings) 
    {
        if (building->isDead()) continue;
        float distance = position.distance(building->getPosition());
        if (distance < minDistance) 
        {
            minDistance = distance;
            closestNode = building;
        }
    }
    return closestNode;
}

Building* BattleManager::findClosestBuildingOfType(Vec2 position, BuildingType type) 
{
    Building* closestNode = nullptr;
    float minDistance = 999999.0f;

    for (auto building : m_buildings) 
    {
        if (building->isDead()) continue;
        if (building->getBuildingType() == type)
        {
            float distance = position.distance(building->getPosition());
            if (distance < minDistance)
            {
                minDistance = distance;
                closestNode = building;
            }
        }
    }
    return closestNode;
}

void BattleManager::addTroop(Troop* troop) 
{
    if (!m_troops.contains(troop)) 
    {
        m_troops.pushBack(troop);
    }
}

void BattleManager::removeTroop(Troop* troop) 
{
    if (m_troops.contains(troop))
    {
        m_troops.eraseObject(troop);
    }
}

Troop* BattleManager::findClosestTroop(Vec2 position, float range) 
{
    Troop* closestTroop = nullptr;
    float minDistance = range;

    for (auto troop : m_troops) 
    {
        if (troop->isDead()) continue;
        float distance = position.distance(troop->getPosition());
        if (distance < minDistance) 
        {
            minDistance = distance;
            closestTroop = troop;
        }
    }
    return closestTroop;
}

void BattleManager::dealAreaDamage(Vec2 center, float radius, int damage)
{
    // ���ռ������Ѫ����ֹ����������
    std::vector<Building*> targetsToHit;

    for (auto building : m_buildings) 
    {
        if (building->isDead()) continue;
        if (building->getPosition().distance(center) <= radius) 
        {
            targetsToHit.push_back(building);
        }
    }

    for (auto building : targetsToHit) 
    {
        if (!building->isDead()) 
        {
            building->takeDamage(damage);
        }
    }
}

// ��ʼ����Ͷ�ű�������
void BattleManager::initAvailableTroops(const std::map<TroopType, int>& availableTroops)
{
    m_availableTroops = availableTroops;
}

// ����Ƿ���Ͷ��ָ������
bool BattleManager::canDeployTroop(TroopType type)
{
    auto it = m_availableTroops.find(type);
    if (it != m_availableTroops.end())
    {
        return it->second > 0;
    }
    return false;
}

// Ͷ�ű��֣����ٿ���������
void BattleManager::deployTroop(TroopType type)
{
    auto it = m_availableTroops.find(type);
    if (it != m_availableTroops.end() && it->second > 0)
    {
        it->second--;
    }
}

// ��ȡָ�����ֵ�ʣ������
int BattleManager::getAvailableTroopCount(TroopType type)
{
    auto it = m_availableTroops.find(type);
    if (it != m_availableTroops.end()) 
    {
        return it->second;
    }
    return 0;
}

// ��ȡ���п��ñ�������
const std::map<TroopType, int>& BattleManager::getAllAvailableTroops() const
{
    return m_availableTroops;
}

void BattleManager::clear() 
{
    m_buildings.clear();
    m_troops.clear();
    m_availableTroops.clear();
}
//BattleManager.cpp