// RecruitUI.cpp
#include "RecruitUI.h"
#include "GameManager.h"
#include "GameUI.h" // Ϊ�˽������ܵ�UI����
#include "ui/CocosGUI.h"
USING_NS_CC;
using namespace ui;

bool RecruitUI::init()
{
    if (!Layer::init()) { return false; }

    Size visibleSize = Director::getInstance()->getVisibleSize();

    // 1. ȫ����͸������
    this->setColor(Color3B::BLACK);
    this->setOpacity(150);
    this->setContentSize(visibleSize);

    // 2. �����
    m_mainPanel = Layout::create();
    m_mainPanel->setContentSize(Size(visibleSize.width * 0.8, visibleSize.height * 0.7));
    m_mainPanel->setBackGroundColorType(Layout::BackGroundColorType::SOLID);
    m_mainPanel->setBackGroundColor(Color3B::BLACK);
    m_mainPanel->setBackGroundColorOpacity(255);
    m_mainPanel->setPosition(Vec2(visibleSize.width * 0.1, visibleSize.height * 0.15));
    this->addChild(m_mainPanel);

    // 3. ��ʼ��UI����
    initUI();

    // 4. ��ʼ����
    this->hide();

    return true;
}

void RecruitUI::initUI()
{
    Size panelSize = m_mainPanel->getContentSize();

    // ����
    auto titleLabel = Label::createWithSystemFont("Recruit Troops", "Arial", 36);
    titleLabel->setPosition(Vec2(panelSize.width / 2, panelSize.height - 50));
    m_mainPanel->addChild(titleLabel);

    // �������ļ�ı���
    std::vector<RecruitItem> items = 
    {
        {"Barbarian", TroopType::BARBARIAN, 50, false},   // 50ʥˮ
        {"Archer", TroopType::ARCHER, 100, false},        // 100ʥˮ
        {"Giant", TroopType::GIANT, 250, false},          // 250ʥˮ
        {"Bomberman", TroopType::BOMBERMAN, 100, false}   // 100ʥˮ
    };

    // �������������ļ��ť
    for (int i = 0; i < items.size(); ++i)
    {
        const auto& item = items[i];
        float y = panelSize.height - 150 - i * 80;

        // ��������
        auto nameLabel = Label::createWithSystemFont(item.name, "Arial", 24);
        nameLabel->setAnchorPoint(Vec2(0, 0.5));
        nameLabel->setPosition(Vec2(50, y));
        m_mainPanel->addChild(nameLabel);

        // ��ļ����
        std::string costStr = std::to_string(item.cost) + (item.isGoldCost ? " Gold" : " Elixir");
        auto costLabel = Label::createWithSystemFont(costStr, "Arial", 20);
        costLabel->setAnchorPoint(Vec2(0, 0.5));
        costLabel->setColor(item.isGoldCost ? Color3B::YELLOW : Color3B::MAGENTA);
        costLabel->setPosition(Vec2(250, y));
        m_mainPanel->addChild(costLabel);

        // ��ļ��ť
        auto recruitBtn = Button::create("CloseNormal.png");
        recruitBtn->setTitleText("Recruit");
        recruitBtn->setTitleFontSize(18);
        recruitBtn->setPosition(Vec2(panelSize.width - 120, y));

        // ��ļ�߼�
        recruitBtn->addClickEventListener
        ([=](Ref*) 
            {
            auto gm = GameManager::getInstance();
            int currentResource = item.isGoldCost ? gm->getGold() : gm->getElixir();

            if (currentResource >= item.cost)
            {
                // ��Դ�㹻��������ļ
                CCLOG("Recruiting %s", item.name.c_str());

                // �۳���Դ
                if (item.isGoldCost) 
                {
                    gm->addGold(-item.cost);
                }
                else 
                {
                    gm->addElixir(-item.cost);
                }

                // ���ӱ�������
                gm->addTroops(item.type, 1);

                // �ַ��¼���֪ͨUI���±�������
                Director::getInstance()->getEventDispatcher()->dispatchCustomEvent("EVENT_UPDATE_TROOPS");

            }
            else 
            {
                // ��Դ����
                CCLOG("Not enough resources to recruit %s!", item.name.c_str());
                // �����������һ������Դ���㡱����ʾ
            }
            }
        );
        m_mainPanel->addChild(recruitBtn);
    }

    // �رհ�ť
    auto closeBtn = Button::create("CloseSelected.png");
    closeBtn->setTitleText("X");
    closeBtn->setTitleFontSize(24);
    closeBtn->setPosition(Vec2(panelSize.width - 30, panelSize.height - 30));
    closeBtn->addClickEventListener
    ([this](Ref*) 
        {
        this->hide();
        }
    );
    m_mainPanel->addChild(closeBtn);
}

void RecruitUI::show()
{
    this->setVisible(true);
}

void RecruitUI::hide()
{
    this->setVisible(false);
}

//ʵ�� onExit ����
void RecruitUI::onExit()
{
    // ȷ���ڽڵ��˳�ʱUI�����صģ���ֹ�����ٹ����б����
    this->hide();

    // ���ø���� onExit��ִ�б�׼����������
    Layer::onExit();
}
// RecruitUI.cpp